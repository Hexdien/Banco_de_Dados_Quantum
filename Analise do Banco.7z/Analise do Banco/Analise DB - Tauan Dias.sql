-- Em qual turma os alunos estão matriculados?
select a.nome, t.nome from aluno as a
join aluno_turma using (id_matricula)
join turma  as t
using (id_turma)

/* Através da query acima é possivel analisar em qual turma aluno está matriculado,
exibindo o seu nome e o nome de respectiva turma */



