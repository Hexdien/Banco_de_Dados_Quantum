


-- Quais os alunos que estão cursando Medicina, quais suas turmas e professores

select a.nome as "Aluno",t.nome as "Turma",d.nome as "Docente" from aluno as a
join aluno_turma USING(id_matricula)
join turma as t USING(id_turma)
join docente_turma using(id_turma)
join docente as d using(id_docente)


/*  A Query acima irá retornar quais alunos estão cursando Medicina, quais as turmas que os mesmos estão inseridos e quais
professores irão dar aulas para eles */