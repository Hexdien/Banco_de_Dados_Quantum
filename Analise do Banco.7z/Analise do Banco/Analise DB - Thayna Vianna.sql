
-- Quais são as disciplinas de físicas, quantas tem e quais suas cargas horarias?

select d.nome,d.ementa,d.carga_horario 
from disciplina as d
where d.nome = 'Física'
order by 3 desc


---Nessa Query falamos quais são as disciplinas de fisica e seus topicos, e quais são suas cargas horarias.