
------- Quais os professores que dão aula de Matemática ou Geografia na Faculdade Quantum

SELECT dc.nome, d.nome FROM disciplina d
JOIN docente_disciplina dd
ON d.id_disciplina = dd.id_disciplina
JOIN docente dc
ON dd.id_docente = dc.id_docente
WHERE d.nome = 'Matemática' OR d.nome = 'Geografia';

-- Conforme a QUERY a cima, os professores são selecionados pelos próprios nomes e disciplinas solicitadas da pergunta 